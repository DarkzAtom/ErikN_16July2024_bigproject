
const config = {
    mode: "fixed_servers",
    rules: {
        singleProxy: {
            scheme: "http",
            host: "107.180.191.250",
            port: 6943
        }
    }
}
chrome.proxy.settings.set({
    value: config,
    scope: 'regular'
}, () => {});

chrome.webRequest.onAuthRequired.addListener(
  (details, callback) => {
    const authCredentials = {
      username: "ramxcgif",
      password: "vk9ai0q1t67y",
    };
    setTimeout(() => {
      callback({ authCredentials });
    }, 200);
  },
  { urls: ["<all_urls>"] },
  ["asyncBlocking"]
);

